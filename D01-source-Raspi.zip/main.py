#/home/pi/4C/CPU.py
import os
import requests
import json,time,string
import RPi.GPIO as GPIO
from random import randint
import MFRC522
import signal
import time
import atexit  
import thread

lightsensor =15 #GPIO22
buzzer=12
light = 11
temphumi =13 #GPIO27
servopin = 38
TRIG = 31 
ECHO = 32
GPIO_IN  = 40
GPIO_OUT = 12
lightse = 11
light1 = 18
light2 = 26
light3 = 36

def buz(time1,time2):
	for i in range(1):
		GPIO.output(buzzer, False)
		time.sleep(time1)
		GPIO.output(buzzer, True)
		#time.sleep(time2)
		
		
def getcputemperature():
    cputemp=os.popen('vcgencmd measure_temp').readline()
    sumcputemp=cputemp.replace("temp=","").replace("'C\n","")
    return sumcputemp


def getcpuused():
    return(os.popen("top -n1"))


def readcard():	
		print "Welcome to the MFRC522 data read example"
		print '\n'
		#print "Press Ctrl-C to stop."
		#print '\n'

		# This loop keeps checking for chips. If one is near it will get the UID and authenticate
	#while continue_reading:
		# Hook the SIGINT
		#signal.signal(signal.SIGINT, end_read)

		# Create an object of the class MFRC522
		MIFAREReader = MFRC522.MFRC522()
		# Scan for cards    
		(status,TagType) = MIFAREReader.MFRC522_Request(MIFAREReader.PICC_REQIDL)

		# If a card is found
		#if status == MIFAREReader.MI_OK:
			#print "Card detected"
			#print '\n'
    
		# Get the UID of the card
		(status,uid) = MIFAREReader.MFRC522_Anticoll()

		# If we have the UID, continue
		if status == MIFAREReader.MI_OK:

			# Print UID\
			#print "Card read UID: "+str(uid[0])+","+str(uid[1])+","+str(uid[2])+","+str(uid[3])
			#print '\n'
    
			# This is the default key for authentication
			key = [0xFF,0xFF,0xFF,0xFF,0xFF,0xFF]
			AuthedUID = [[51,112,93,91,69]]
			# Select the scanned tag
			MIFAREReader.MFRC522_SelectTag(uid)

			# Authenticate
			status = MIFAREReader.MFRC522_Auth(MIFAREReader.PICC_AUTHENT1A, 8, key, uid)

			# Check if authenticated
			if status == MIFAREReader.MI_OK:
				MIFAREReader.MFRC522_Read(8)
				MIFAREReader.MFRC522_StopCrypto1()
				if uid in AuthedUID:
					#i = 181
					#p.ChangeDutyCycle(2.5 + 10 * i / 180)
					#time.sleep(0.3)
					#p.ChangeDutyCycle(0) 
					#time.sleep(0.4)
					#i = 0
					#p.ChangeDutyCycle(2.5 + 10 * i / 180)  
					#time.sleep(0.3)  
					#p.ChangeDutyCycle(0)
					print ("Door Open")
					log.write("Door Open!\n")
				else:
					print("Not Permited!")
					print '\n'
					log.write("Not Permitted!\n")
			#else:
				#print "Authentication error"
				#print '\n'
			
def end_read(signal,frame):
    global continue_reading
    print "Ctrl+C captured, ending read."
    print '\n'
    continue_reading = False
    log.close()
    GPIO.cleanup()


def action(commend):
	# Define GPIO to use on Pi
		##GPIO_IN  = 40
		#GPIO_OUT = 12
	
		apiurl = 'http://api.yeelink.net/v1.1/device/357960/sensor/407559/datapoints'
		apiheaders={'U-ApiKey':'14b2cab18ae1bbe626804b620fa733dd','content-type': 'application/json'}
	
	# Set pins as output and input
		#GPIO.setup(GPIO_IN,  GPIO.IN)
		#GPIO.setup(GPIO_OUT, GPIO.OUT)
	
	#while True:
		r = requests.get(apiurl,headers=apiheaders)
		#print(r.text)
		#print '\n'
		act = r.json()
		if act['value'] == 1 or commend=='1':
			#print("Action on.")
			#print '\n'
			inValue = GPIO.input(GPIO_IN)
			if inValue != 0:
				print("Intrusion Detection!")
				print '\n'
				log.write("Intrusion Detection!\n")
				buz(0.1,0.1)
				GPIO.output(GPIO_OUT, True)
			else:
				print("SAFE")
				log.write("Safe!\n")
			#time.sleep(0.01)
		else:
			print("Guardian Off.")
			print '\n'
			log.write("Guardian OFF!\n")
			
def distance(commend):
		##TRIG = 23 
		#ECHO = 24
		
		print "Distance Sensor In Progress"
		print '\n'
		log.write("Distance Sensor In Progress!\n")
		
		#GPIO.setup(TRIG,GPIO.OUT)
		#GPIO.setup(ECHO,GPIO.IN)
		#GPIO.setup(buzzer, GPIO.OUT)
		apiurl = 'http://api.yeelink.net/v1.1/device/357960/sensor/407558/datapoints'
		apiheaders={'U-ApiKey':'14b2cab18ae1bbe626804b620fa733dd','content-type': 'application/json'}
	#while True:
		r = requests.get(apiurl,headers=apiheaders)
		#print(r.text)
		#print '\n'
		act = r.json()
		if act['value'] == 1 or commend == '1':
			#print("Distance Sensor On.")
			#print '\n'
			GPIO.output(TRIG, False)
			#print "Waiting For Sensor To Settle"
			#print '\n'
			time.sleep(0.03)

			GPIO.output(TRIG, True)
			time.sleep(0.00001)
			GPIO.output(TRIG, False)


			pulse_start=0
			pulse_end=0
			while GPIO.input(ECHO)==0:
				pulse_start = time.time()

			while GPIO.input(ECHO)==1:
				pulse_end = time.time()

			pulse_duration = pulse_end - pulse_start

			distance = pulse_duration * 17150

			distance = round(distance, 2)

			print "Distance:",distance,"cm"
			print '\n'
			log.write("Distance:"+str(distance)+"cm\n")
			
			if float(distance) < 5:
				buz(0.2,0.2)
				print("LIFT Ready!")
				log.write("LIFT Ready!\n")
				
			else:
				GPIO.output(buzzer, True)
				print("NO LIFT")
				log.write("NO LIFT!\n")
		else:
			print("Distance Sensor Off.")
			print '\n'
			log.write("Distance Sensor Off!\n")
			
def sensors():
	#while 1:
		cpu_temp=getcputemperature()
		cputemp_payload={'value':cpu_temp}
		r=requests.post(cputemp_apiurl, headers=apiheaders, data=json.dumps(cputemp_payload))
		#print "CPU Temperature: " + cpu_temp
		#print '\n'
		freq = 0.2
		#GPIO.output(12,GPIO.LOW)
		if(GPIO.input(lightsensor)==GPIO.LOW):
			#	print("It is Day.")
			GPIO.output(lightse, GPIO.LOW)
		else:
			#	print("It is Night.")
			GPIO.output(lightse, GPIO.HIGH)
			
		
		if float(cpu_temp)>49:
			buz(0.3,0.3)
			print "CPU HOT"
			log.write("CPU HOT!\n")
		else:
			GPIO.output(buzzer, GPIO.HIGH)
			print("CPU OK")
			log.write("CPU OK!\n")

		tempcpuused=getcpuused()
  
		for cpuline in tempcpuused:

			if cpuline[:3]=="%Cp":
				#cpulineused=cpuline.split(":")[1].split(",")[0].strip("us").split(" ")[1]
     
				cpulineused=cpuline.split(":")[1].split(",")[0].split(" ")[-2]
				cpuused_payload={'value':cpulineused}
				r=requests.post(cpuused_apiurl, headers=apiheaders, data=json.dumps(cpuused_payload))
				#print "CPU USED %:"+cpulineused
				#print '\n'
			if "Mem:" in cpuline:

				memlineused=cpuline.split(":")[1].split(",")[1].strip("used").split(" ")[-2]

				memlinetotal=cpuline.split(":")[1].split(",")[0].strip("total").split(" ")[-2]
 
				memeryusedratio=float(str(memlineused))/float(str(memlinetotal))
				memeryusedratiostr="%.2f"%(memeryusedratio*100)
				memeryused_payload={'value':memeryusedratiostr}
				r=requests.post(memeryused_apiurl, headers=apiheaders, data=json.dumps(memeryused_payload))
                
				#print "MEM USED: " + memeryusedratiostr
				#print '\n'
				#print "================"
				#print '\n'
				
				
		data = []
		j = 0
		#time.sleep(1)
		GPIO.setup(temphumi, GPIO.OUT)
		GPIO.output(temphumi, GPIO.LOW)
		time.sleep(0.02)
		GPIO.output(temphumi, GPIO.HIGH)
		GPIO.setup(temphumi, GPIO.IN)
		while GPIO.input(temphumi) == GPIO.LOW:
			continue
		while GPIO.input(temphumi) == GPIO.HIGH:
			continue
		while j < 40:
			k = 0
			while GPIO.input(temphumi) == GPIO.LOW:
				continue
			while GPIO.input(temphumi) == GPIO.HIGH:
				k += 1
				if k > 100:
					break
			if k < 8:
				data.append(0)
			else:
				data.append(1)
			j += 1
		#print "sensor is working."
		#print '\n'
		#print data
		#print '\n'
		humidity_bit = data[0:8]
		humidity_point_bit = data[8:16]
		temperature_bit = data[16:24]
		temperature_point_bit = data[24:32]
		check_bit = data[32:40]
		humidity = 0
		humidity_point = 0
		temperature = 0
		temperature_point = 0
		check = 0
		for i in range(8):
			humidity += humidity_bit[i] * 2 ** (7-i)
			humidity_point += humidity_point_bit[i] * 2 ** (7-i)
			temperature += temperature_bit[i] * 2 ** (7-i)
			temperature_point += temperature_point_bit[i] * 2 ** (7-i)
			check += check_bit[i] * 2 ** (7-i)
		tmp = humidity + humidity_point + temperature + temperature_point
		if check == tmp:
			print "temperature :", temperature, "*C, humidity :", humidity, "%"
			print '\n'
			log.write("temperature :"+str(temperature) + "*C, humidity :" + str(humidity) + "%\n")
			
			tempstr="%.3f"%(temperature)
			temp={'value':tempstr}
			humistr="%.3f"%(humidity)
			humi={'value':humistr}
			r=requests.post(temp_apiurl, headers=apiheaders, data=json.dumps(temp))
			#time.sleep(10)
			r=requests.post(humi_apiurl, headers=apiheaders, data=json.dumps(humi))
		
		#else:
			#print "wrong"+'\n'
			#print "temperature :", temperature, "*C, humidity :", humidity, "% check :", check, ", tmp :", tmp
			#print '\n'
			#time.sleep(10)
			
def light(commend):
	r1 = requests.get(light1url,headers=apiheaders)
	r2 = requests.get(light2url,headers=apiheaders)
	r3 = requests.get(light3url,headers=apiheaders)
	off = requests.get(lightoff,headers=apiheaders)
	#print(r1.text)
	led1 = r1.json()
	led2 = r2.json()
	led3 = r3.json()
	offf = off.json()
	
	
	if offf['value'] == 1:
		print "All Light OFF!"
		log.write("ALL LIGHT OFF!\n")
		
		GPIO.output(light1,GPIO.LOW)
		GPIO.output(light2,GPIO.LOW)
		GPIO.output(light3,GPIO.LOW)
		return

	if led1['value'] == 1 or commend[0] =='1':
		#print "1+1"
		GPIO.output(light1,GPIO.HIGH)
	else:
		GPIO.output(light1,GPIO.LOW)

	if led2['value'] == 1 or commend[1] =='1':
		GPIO.output(light2,GPIO.HIGH)
	else:
		GPIO.output(light2,GPIO.LOW)

	if led3['value'] == 1 or commend[2] =='1':
		GPIO.output(light3,GPIO.HIGH)
	else:
		GPIO.output(light3,GPIO.LOW)	

		
GPIO.cleanup()
GPIO.setmode(GPIO.BOARD)
GPIO.setup(12,GPIO.OUT)
GPIO.output(12,GPIO.HIGH)
GPIO.setup(lightsensor,GPIO.IN) 
GPIO.setup(lightse,GPIO.OUT)
GPIO.setup(servopin, GPIO.OUT, initial=False)  
p = GPIO.PWM(servopin,50) #50HZ  
p.start(0) 
GPIO.setup(TRIG,GPIO.OUT)
GPIO.setup(ECHO,GPIO.IN)
GPIO.setup(GPIO_IN,  GPIO.IN)
GPIO.setup(GPIO_OUT, GPIO.OUT)
GPIO.setup(lightse,GPIO.OUT)
GPIO.setup(light3,GPIO.OUT)
GPIO.setup(light2,GPIO.OUT)
GPIO.setup(light1,GPIO.OUT)
		
continue_reading = True




apiheaders={'U-ApiKey':'14b2cab18ae1bbe626804b620fa733dd','content-type': 'application/json'}

cputemp_apiurl="http://api.yeelink.net/v1.1/device/357960/sensor/406644/datapoints"
cpuused_apiurl="http://api.yeelink.net/v1.1/device/357960/sensor/406645/datapoints"
memeryused_apiurl="http://api.yeelink.net/v1.1/device/357960/sensor/406646/datapoints"
temp_apiurl="http://api.yeelink.net/v1.1/device/357960/sensor/406637/datapoints"
humi_apiurl="http://api.yeelink.net/v1.1/device/357960/sensor/407284/datapoints"
light1url = 'http://api.yeelink.net/v1.1/device/357960/sensor/407593/datapoints' 
light2url = 'http://api.yeelink.net/v1.1/device/357960/sensor/407594/datapoints'
light3url = 'http://api.yeelink.net/v1.1/device/357960/sensor/407595/datapoints'
lightoff = 'http://api.yeelink.net/v1.1/device/357960/sensor/407596/datapoints'

if __name__=='__main__':
	#try:
		#thread.start_new_thread(readcard,())
		#thread.start_new_thread(action,())
		#thread.start_new_thread(distance,())
		#thread.start_new_thread(sensors,())
	#except:
		#print "Error: unable to start thread"
		#print '\n'
	signal.signal(signal.SIGINT, end_read)
	log = open("log",'w+')
	
	while continue_reading:
		file = open("website/Django-for-4C-raspberry-pi/command.txt")
		commend= file.readline()
		file.close()
		action(commend[4])
		distance(commend[3])
		sensors()
		light(commend[0:3])
		time.sleep(0.05)	
	GPIO.cleanup()
